<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8" content="index, follow"/>
    <title>Чуркин Кирилл</title>
</head>
<body background="bg.png">

<div style="text-align: center;">

    <a href="index.php"><p><font size="8"><span style="color: #f5f5f5; ">На главную</span></font></p></a>
    <p><font size="6"><span style="color: #f5f5f5; ">Источники</span></font></p>

    <a href="https://ilyakhasanov.ru/baza-znanij/grafika-i-tekst/besshovnye-fony"><p><span style="color: #f5f5f5; ">Коллекция бесшовных фонов для сайта</span></p></a>
    <a href="https://www.youtube.com/watch?v=D_K7g5MeJPw"><p><span style="color: #f5f5f5; ">Переход на другую страницу через гиперссылкы</span></p></a>
    <a href="https://www.youtube.com/watch?v=-K55ms3mTHg"><p><span style="color: #f5f5f5; ">Установка PhpStorm и первый проект</span></p></a>
    <a href="https://zarabotat-na-sajte.ru/uroki-html/kak-izmenit-cvet-teksta.html"><span style="color: #f5f5f5; ">Изменение цвета текста</span></p></a>


</div>
</body>
</html>