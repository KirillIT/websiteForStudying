<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8" content="index, follow"/>
    <title>Чуркин Кирилл</title>
</head>
<body background="bg.png">

<div style="text-align: center;">

    <a href="index.php"><p><font size="8"><span style="color: #f5f5f5; ">На главную</span></font></p></a>
    <p><font size="6"><span style="color: #f5f5f5; ">О сайте</span></font></p>
    <p><span style="color: #f5f5f5; ">Данный сайт создаётся как сайт, который нужно сделать для аттестиции по учебной дисциплине "Web-технологии".</span></p>
    <p><span style="color: #f5f5f5; ">Однако это не значит, что сайт в дальнейшем не будет развиваться и улучшаться.</span></p>
    <p><span style="color: #f5f5f5; ">В будущем это будет мой личный сайт, верояно.</span></p>

</div>
</body>
</html>