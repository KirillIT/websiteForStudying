<?php
$last = "никогда";
setcookie("last", "никогда", time()+3600*12*24*30);
?>

<body background="bg.png">

<div style="text-align: center;">

    <p><font size="6"><span style="color: #f5f5f5; ">Данные о времени последнего посещения сайта удалены</span></font></p>


</div>>
</body>




