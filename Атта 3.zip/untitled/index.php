<!doctype html>

<html lang="ru">
<head>
    <meta charset="UTF-8" content="index, follow"/>
    <title>Чуркин Кирилл</title>
</head>
<body background="bg.png">
<div style="text-align: center;">
<p><font size="8"><span style="color: #f5f5f5; ">Главная</span></font></p>
    <a href="aboutTheAuthor.php"><p><font size="6"><span style="color: #f5f5f5; ">Об авторе</span></font></p></a>
<a href="aboutTheSite.php"><p><font size="6"><span style="color: #f5f5f5; ">О сайте</span></font></p></a>
<a href="sources.php"><p><font size="6"><span style="color: #f5f5f5; ">Источники</span></font></p></a>
    <a href="maxmin.php"><p><font size="6"><span style="color: #f5f5f5; ">Программирование на сервере</span></font></p></a>
</div>

</body>
</html>