<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.1.3
 */

/**
 * Database `a0678543_crud`
 */

/* `a0678543_crud`.`crud` */
$crud = array(
  array('id' => '162','value' => '234'),
  array('id' => '163','value' => '162'),
  array('id' => '164','value' => '15'),
  array('id' => '165','value' => '1000'),
  array('id' => '166','value' => '7'),
  array('id' => '167','value' => '993'),
  array('id' => '168','value' => '228'),
  array('id' => '169','value' => '322'),
  array('id' => '170','value' => '69'),
  array('id' => '171','value' => '1984'),
  array('id' => '172','value' => '0')
);
